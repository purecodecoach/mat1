===============
AXI Fan Control
===============

Fan controller IP core

Link to `wiki-page
<https://wiki.analog.com/resources/fpga/docs/axi_fan_control>`_
