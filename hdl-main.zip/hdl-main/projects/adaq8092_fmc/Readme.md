# ADAQ8092_FMC HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/EVAL-ADAQ8092)
  * Parts : [2 Channels, 14-Bit, 105 MSPS, Analog-to-Digital Converter](https://www.analog.com/adaq8092)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guide/adaq8092-eval-board
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/adaq8092
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-adc/adaq8092
