# AD-DAC-FMC-EBZ reference HDL design for VCU118

|||
| ------ | ------ |
| Wiki  | https://wiki.analog.com/resources/eval/user-guides/ad-dac-fmc-ebz |
| FMC Location | FMCP HSPC Slot |
| Configuration file | ../common/config.tcl |
