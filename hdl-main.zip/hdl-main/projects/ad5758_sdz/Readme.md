# AD5758-SDZ HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/EVAL-AD5758)
  * Parts : [Single-Channel, 16-Bit Current and Voltage Output DAC with Dynamic Power Control and HART Connectivity](https://www.analog.com/ad5758)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/ad5758
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad5758
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-dac/ad5758
