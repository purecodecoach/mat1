# ARRADIO HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.terasic.com.tw/cgi-bin/page/archive.pl?Language=English&CategoryNo=65&No=946)
  * Parts : [RF Agile Transceiver](https://www.analog.com/ad9361)
  * Project Doc: https://wiki.analog.com/resources/eval/user-guides/arradio
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad-fmcomms2-ebz/reference_hdl
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-transceiver/ad9361
