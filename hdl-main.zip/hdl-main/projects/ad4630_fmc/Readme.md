# AD4630-24 Eval FMC HDL Project

Here are some pointers to help you:
  * [Board Product Page]( https://www.analog.com/eval-ad4630-24)
  * Parts : [24-Bit, 2 MSPS, Dual Channel, Precision Differential SAR ADC](https://www.analog.com/ad4630-24)
            [24-Bit, 500 kSPS, Dual Channel SAR ADC](https://www.analog.com/AD4632-24)
  * Project Doc: https://wiki.analog.com/resources/eval/ad4630-24-eval-board
  * HDL Doc: https://wiki.analog.com/resources/eval/user-guides/ad463x/hdl
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/uc-drivers/ad463x
