# USRPE31X HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.ettus.com/all-products/e310)
  * Parts : [RF Agile Transceiver](https://www.analog.com/ad9363)
  * Project Doc: 
  * HDL Doc: 
  * Linux Drivers: https://wiki.analog.com/resources/tools-software/linux-drivers/iio-transceiver/ad9361
