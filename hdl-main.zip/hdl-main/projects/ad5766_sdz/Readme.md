# AD5766-SDZ HDL Project

Here are some pointers to help you:
  * [Board Product Page](https://www.analog.com/EVAL-AD5766)
  * Parts : [AD5766, 16-Channel, 16-Bit Voltage Output denseDAC](https://www.analog.com/ad5766)
            [AD5767, 16-Channel, 12-Bit Voltage Output denseDAC](https://www.analog.com/ad5767)
  * Project Doc: 
  * HDL Doc: 
  * NO-OS Drivers: [AD5766 - No-OS Driver](https://wiki.analog.com/resources/tools-software/uc-drivers/ad5766)
  * Linux Drivers: https://git.kernel.org/pub/scm/linux/kernel/git/torvalds/linux.git/tree/drivers/iio/dac/ad5766.c
